import 'package:flutter/material.dart';


List itemsTab = [
  {"icon": Icons.home_rounded, "size": 30.0, "label": Text('Home')},
  // {"icon": Icons.play_circle_fill_outlined, "size": 30.0, "label": Text('Home')},
  {"icon": Icons.search, "size": 30.0, "label": Text('Home')},
  // {"icon": Icons.account_circle_rounded, "size": 30.0, "label": Text('Home')},
//  {"icon": Icons.account_circle_rounded, "size": 30.0, 
//  "label": Text('Home')},
  ];




const textcolour = Color(0xFF3A0072); 
const kSecondaryColor = Color(0xFF3BEABB);
const black = Color(0xFF000000);
const white = Color(0xFFffffff);
const grey = Colors.grey;
const searchboxgrey = Color(0XFFF7F7F7);
const percentage = Color(0XFF50CD89);
const cap = Color(0XFFC91288);
const searchbarlight = Color(0XFF6A0FC2);





