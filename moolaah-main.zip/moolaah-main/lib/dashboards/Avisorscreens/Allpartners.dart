import 'package:flutter/material.dart';
import 'package:moolah/coponents/constant.dart';

class Allpartners extends StatefulWidget {
  const Allpartners({ Key? key }) : super(key: key);

  @override
  State<Allpartners> createState() => _AllpartnersState();
}

class _AllpartnersState extends State<Allpartners> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: textcolour),
      
    );
  }
}