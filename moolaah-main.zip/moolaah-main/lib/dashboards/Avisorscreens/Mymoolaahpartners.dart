import 'package:flutter/material.dart';

class Mymollaahpartners extends StatefulWidget {
  const Mymollaahpartners({ Key? key }) : super(key: key);

  @override
  State<Mymollaahpartners> createState() => _MymollaahpartnersState();
}

class _MymollaahpartnersState extends State<Mymollaahpartners> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}