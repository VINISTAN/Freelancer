import 'package:flutter/cupertino.dart';

class ChatUsers{
  String name;
  String messageText;
  String image;
  String time;
  ChatUsers({required this.name,required this.messageText,required this.image,required this.time, required String secondaryText, required Object imageURL, required String text, });
}